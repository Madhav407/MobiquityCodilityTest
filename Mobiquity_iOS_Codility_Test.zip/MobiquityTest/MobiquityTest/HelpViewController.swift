//
//  HelpViewController.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 13/06/21.
//

import UIKit

class HelpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
        self.title = "Help"
        // Do any additional setup after loading the view.
    }
    

    func configureUI()
    {
        let navHt = self.navigationController?.navigationBar.frame.height ?? 0
       let tabbarHt = self.tabBarController?.tabBar.frame.height ?? 0
       
       let rquiredHt = SCREEN_HEIGHT - (navHt )
        let helpView = HellpWebview(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH , height: rquiredHt))
        self.view = helpView
    }

}
