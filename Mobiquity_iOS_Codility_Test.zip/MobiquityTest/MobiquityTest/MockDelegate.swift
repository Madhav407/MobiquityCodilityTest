//
//  MockDelegate.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import UIKit

public class MockDelegate :  ListViewDelegate {    
    func refreshBookmarkedLocationsList(){}
    func locationSelected(location: LocationModel){}
    func updateBookMarkWhileLocationChanged(){}
    func updateNewBookMarkForSelectedLocationONMap(lat: Double, lon:Double){}
}
