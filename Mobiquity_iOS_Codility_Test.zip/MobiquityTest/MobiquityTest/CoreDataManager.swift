//
//  CoreDataManager.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 13/06/21.
//

import UIKit
import CoreData
let entityName = "LocationModel"

//extension Double {
//
//   func formatted(_ decimalPlaces: Int?) -> String {
//      let theDecimalPlaces : Int
//      if decimalPlaces != nil {
//         theDecimalPlaces = decimalPlaces!
//      }
//      else {
//         theDecimalPlaces = 2
//      }
//      let theNumberFormatter = NumberFormatter()
//      theNumberFormatter.formatterBehavior = .behavior10_4
//      theNumberFormatter.minimumIntegerDigits = 1
//      theNumberFormatter.minimumFractionDigits = 1
//      theNumberFormatter.maximumFractionDigits = theDecimalPlaces
//      theNumberFormatter.usesGroupingSeparator = true
//      theNumberFormatter.groupingSeparator = " "
//      theNumberFormatter.groupingSize = 3
//
//      if let theResult = theNumberFormatter.string(from: NSNumber(value:self)) {
//         return theResult
//      }
//      else {
//         return "\(self)"
//      }
//   }
//}

class CoreDataManager: NSObject {
    static let shared = CoreDataManager()
    let appDelegate = UIApplication.shared.delegate as? AppDelegate
    
    func insertLocation(latitude: Float?, longitude: Float?, locName:String)
    {
        
        if !isLocationExist(lat: latitude ?? 0.0, lon: longitude ?? 0.0)
        {
        
        let context = appDelegate?.persistentContainer.viewContext
        let insertModel = NSEntityDescription.insertNewObject(forEntityName: "LocationModel", into: context!) as? LocationModel
        
        insertModel?.latitude = Float(latitude ?? 0.0)
        insertModel?.longitude = Float(longitude ?? 0.0)
        insertModel?.locationName = locName ?? ""
        
         if let appDel = appDelegate
         {
            appDel.saveContext()
         }
        }
        else
        {
            print("location already exist")
        }
    }
    
    func isLocationExist(lat:Float, lon:Float) ->Bool
    {
        let context = appDelegate?.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        let pred1 = NSPredicate(format: "latitude = %d", lat)
        let pred2 = NSPredicate(format: "longitude = %d", lon)
//        request.predicate = NSCompoundPredicate(andPredicateWithSubpredicates:[pred1,pred2])
//        request.predicate = NSPredicate(format: "latitude == %f AND longitude == %f", lat, lon)

       //s request.predicate = predicatesAND
        request.predicate = NSPredicate(format: "latitude = %f AND longitude = %f", lat, lon)

//        Optional(19.0176)
//        Optional(72.8562)
        do
        {
            if let results = try context?.fetch(request) as? [LocationModel]
            {
                print("result ocunt = \(results.count)")
                if results.count>0
                {
                    return true
                }
            }
        }
        catch{
        }
        return false
    }
    
    func fetchBookmarkedLocations() ->[LocationModel]?
    {
        let context = appDelegate?.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
//        request.predicate = NSPredicate(format: "latitude = %f", "12")
        do
        {
            let results = try context?.fetch(request) as? [LocationModel]
            print("result count = \(results?.count ?? 0)")
            return results
        }
        catch
        {  }
        return nil
    }
    
    func removeAll()
    {
        let context = appDelegate?.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        do
        {
            if let results = try context?.fetch(request) as? [NSManagedObject]
            {
            for item in results
            {
                context?.delete(item)
                appDelegate?.saveContext()
            }
            }
        }
        catch{ print(error) }
    }

    func removeBookmark(lat: Float, lon:Float)
    {
        let context = appDelegate?.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        request.predicate = NSPredicate(format: "latitude = %f", lat)
        let pred1 = NSPredicate(format: "latitude = %f", lat)
        let pred2 = NSPredicate(format: "longitude = %f", lon)
        let andPredicate = NSCompoundPredicate(type: .and, subpredicates: [pred1,pred2])
//        request.predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [pred1,pred2])
        request.predicate  = NSCompoundPredicate(type: .and, subpredicates: [pred1,pred2])
        do
        {
            if let results = try context?.fetch(request) as? [NSManagedObject]
            {
            for item in results
            {
                context?.delete(item)
                appDelegate?.saveContext()
            }
            
            }
        }
        catch
        {
           print(error)
        }
    }
    
}
