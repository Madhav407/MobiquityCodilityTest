//
//  MapViewController.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 13/06/21.
//

import UIKit
import MapKit
import CoreLocation

//Due to vaccination got sick, due to time constraint for this screen only not being completed used MVVM design.
class MapViewController: UIViewController , MKMapViewDelegate, UIGestureRecognizerDelegate{

    @IBOutlet  var mapView: MKMapView! //due to unitest case weak reference removed for outlet
//    var model : LocationModel?
    var delegate : ListViewDelegate?
    var  coordinate : CLLocationCoordinate2D?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        gestureRecognizer.delegate = self
        mapView.addGestureRecognizer(gestureRecognizer)
        addCurrentLocation()
        
        let add = UIBarButtonItem(title: "Bookmark", style: .plain, target: self, action: #selector(addToBookMarks))
        self.navigationItem.rightBarButtonItem = add
        // Do any additional setup after loading the view.
    }
    
   @objc func addToBookMarks()
    {
    self.delegate?.updateNewBookMarkForSelectedLocationONMap(lat: coordinate!.latitude, lon: coordinate!.longitude)
    self.navigationController?.popViewController(animated: true)
    }

    func addCurrentLocation()
    {
        let span = MKCoordinateSpan(latitudeDelta: 0.025, longitudeDelta: 0.025)
        
         let coordinate = CLLocationCoordinate2D(latitude:LocationServices.shared.currentLatitude ?? 0.0 , longitude: LocationServices.shared.currentLongitude ?? 0.0)

        
        let region = MKCoordinateRegion(center: coordinate, span: span)
        
        mapView.setRegion(region, animated: true)
        
        
        let pin = MKPointAnnotation()
        pin.coordinate = coordinate
//        pin.title = model?.locationName ?? ""
        mapView.addAnnotations([pin])
        
    }
    
    @objc func handleTap(_ gestureReconizer: UITapGestureRecognizer)
        {

        let location = gestureReconizer.location(in: mapView)
        coordinate = mapView.convert(location,toCoordinateFrom: mapView)

        print("selected coordinate = \(coordinate)")
        // Add annotation:
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate!
        mapView.removeAnnotations(mapView.annotations)
        mapView.addAnnotation(annotation)
        }

//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//
//    for touch in touches {
//        let touchPoint = touch.location(in: mapView)
//        let location = mapView.convert(touchPoint, toCoordinateFrom: mapView)
//        print ("\(location.latitude), \(location.longitude)")
//    }}
}
