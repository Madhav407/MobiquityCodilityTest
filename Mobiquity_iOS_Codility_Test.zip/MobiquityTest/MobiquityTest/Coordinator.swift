//
//  Coordinator.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import Foundation

struct Coordinator {
    
    @discardableResult
    init(getTodayForecastVC viewModel: TodayForecastViewModel?, viewController:(TodayForecastViewController)->Void)  {
        let vc = TodayForecastViewController(viewModel: viewModel)
        vc.title = "Today's Forecast Weather"
        viewController(vc)
    }
    
    @discardableResult
    init(getFiveDayForecastDetailsVC viewModel : ForecastDetailViewModel?, viewController :(ForecastWeatherViewController) ->Void) {
        let detailsVC = ForecastWeatherViewController(viewModel: viewModel)
        detailsVC.title = "Forecast Weather"
        viewController(detailsVC)
    }
}
