//
//  TodayForecastViewModel.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import UIKit

class TodayForecastViewModel: NSObject {
    var weatherModel: LocationsModel?
    
    init(model:LocationsModel?) {
        self.weatherModel = model
    }
  

}
