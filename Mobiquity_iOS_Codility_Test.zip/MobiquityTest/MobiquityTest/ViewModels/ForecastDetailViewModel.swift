//
//  ForecastDetailViewModel.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 14/06/21.
//

import UIKit
extension Sequence {
    func groupSort(ascending: Bool = true, byDate dateKey: (Iterator.Element) -> Date) -> [[Iterator.Element]] {
        var categories: [[Iterator.Element]] = []
        for element in self {
            let key = dateKey(element)
            guard let dayIndex = categories.index(where: { $0.contains(where: { Calendar.current.isDate(dateKey($0), inSameDayAs: key) }) }) else {
                guard let nextIndex = categories.index(where: { $0.contains(where: { dateKey($0).compare(key) == (ascending ? .orderedDescending : .orderedAscending) }) }) else {
                    categories.append([element])
                    continue
                }
                categories.insert([element], at: nextIndex)
                continue
            }

            guard let nextIndex = categories[dayIndex].index(where: { dateKey($0).compare(key) == (ascending ? .orderedDescending : .orderedAscending) }) else {
                categories[dayIndex].append(element)
                continue
            }
            categories[dayIndex].insert(element, at: nextIndex)
        }
        return categories
    }
}

class ForecastDetailViewModel: NSObject {

    var forecastModel:  ForecastDetailModel?
    var sectionTitlesArray: [String]?
    var groupSortedArray : [Any]?
    
     init(forecastModel: ForecastDetailModel?) {
        super.init()
        self.forecastModel = forecastModel
        self.prepareSectionsArray()
    }
    
    func prepareGroupSortedArray()
    {
        var filterGroupArray = self.forecastModel?.list?.groupSort(ascending: true, byDate: { (item : List) -> Date in
            
            return getDateFromString(string: item.dtTxt ?? "")
        })
        self.groupSortedArray = filterGroupArray
        print(groupSortedArray?.count)
        print(groupSortedArray)
        
    }
    func getDateFromString(string : String)->Date
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss" //"2021-06-13 21:00:00"
        return dateFormatter.date(from: string) ?? Date()
    }
    
    func prepareSectionsArray()
    {
        prepareGroupSortedArray()
    }
}
