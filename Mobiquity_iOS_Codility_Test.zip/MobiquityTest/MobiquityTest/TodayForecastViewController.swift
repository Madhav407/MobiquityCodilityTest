//
//  TodayForecastViewController.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import UIKit

class TodayForecastViewController: UIViewController {
    var viewModel : TodayForecastViewModel?
    var todayView : TodayForecastView?
    init(viewModel : TodayForecastViewModel?) {
        super.init(nibName: nil, bundle: nil)
        self.viewModel = viewModel
        prepareViewSetup()
    }
    
    required init?(coder: NSCoder?) {
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Today's Forecast Weather"
        // Do any additional setup after loading the view.
    }
    
    func prepareViewSetup()
    {
        let navHt = self.navigationController?.navigationBar.frame.height ?? 0
       let tabbarHt = self.tabBarController?.tabBar.frame.height ?? 0
       
       let requiredHt = SCREEN_HEIGHT - (navHt + tabbarHt)
        todayView = TodayForecastView(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: requiredHt), viewModel: self.viewModel)
        
        self.view = todayView!
    }

}
