//
//  Extensions.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import Foundation
import UIKit

extension Double {
    func roundedTo(decimals: Int)-> Double {
        return Double(floor(pow(10.0, Double(decimals)) * self)/pow(10.0, Double(decimals)))
    }
    
}

extension Float {
    func roundedTo(decimals: Int) -> Float {
        var formatter = NumberFormatter()
        formatter.maximumFractionDigits = 4
        formatter.minimumFractionDigits = 4
        
        return Float(floor(pow(10.0, Double(decimals)) * Double(self))/pow(10.0, Double(decimals)))
//        formatter.val
        return 0.0
    }
    
}

extension UIView {

    func addShadow(offset: CGSize, color: UIColor, radius: CGFloat, opacity: Float) {
        layer.masksToBounds = false
        layer.shadowOffset = offset
        layer.shadowColor = color.cgColor
        layer.shadowRadius = radius
        layer.shadowOpacity = opacity

        let backgroundCGColor = backgroundColor?.cgColor
        backgroundColor = nil
        layer.backgroundColor =  backgroundCGColor
    }
}
