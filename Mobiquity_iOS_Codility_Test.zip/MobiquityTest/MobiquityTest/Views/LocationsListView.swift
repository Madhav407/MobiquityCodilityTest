//
//  ListView.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 13/06/21.
//

import UIKit
import CoreData


enum CellIdentifier : String{
    case LocationCellIdentifier = "WeatherLocationTableViewCell"
    case ForecastTableViewCell = "ForecastTableViewCell"
}
protocol ListViewDelegate : class {
    
    func refreshBookmarkedLocationsList()
    func locationSelected(location: LocationModel)
    func updateBookMarkWhileLocationChanged()
    func updateNewBookMarkForSelectedLocationONMap(lat: Double, lon:Double)

}

class LocationsListView: UIView {

    var viewModel: LocationsListViewModel?
    var locationTableView : UITableView
    var delegate : ListViewDelegate?
    var isEdit = true
    init(frame: CGRect, viewModel : LocationsListViewModel?, delegate : ListViewDelegate?) {
        self.locationTableView = UITableView()
        self.delegate = delegate
        self.viewModel = viewModel

        if viewModel == nil
        {
            self.viewModel = LocationsListViewModel(model: nil, delegate: delegate)
        }
        super.init(frame: frame)
        configureUI()

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func fetchList()
    {
        self.viewModel?.fetchCurrentLocationWeatherData()
    }
    
    func configureUI()
    {
        self.viewModel?.delegate = self.delegate
        self.backgroundColor = .white
//        locationTableView = UITableView()
        addSubview(locationTableView)
                
                // TableView - Configuration + Style
        locationTableView.estimatedRowHeight = 60
        locationTableView.rowHeight = UITableView.automaticDimension
        
        let nib = UINib(nibName: "WeatherLocationTableViewCell", bundle: Bundle.main)

        locationTableView.register(nib, forCellReuseIdentifier: CellIdentifier.LocationCellIdentifier.rawValue)
        locationTableView.delegate = self
        locationTableView.dataSource = self
        // TableView - Auto layout
        locationTableView.translatesAutoresizingMaskIntoConstraints = false
//        locationTableView.layer.borderWidth = 1
        let margins = self.safeAreaLayoutGuide
        locationTableView.leadingAnchor.constraint(equalTo: margins.leadingAnchor).isActive = true
        locationTableView.trailingAnchor.constraint(equalTo: margins.trailingAnchor).isActive = true
        locationTableView.topAnchor.constraint(equalTo: margins.topAnchor).isActive = true
        locationTableView.bottomAnchor.constraint(equalTo: margins.bottomAnchor).isActive = true
        locationTableView.bottomAnchor.constraint(equalTo: margins.bottomAnchor, constant: 50).isActive = true
        
    }
    
    func refreshLocationList(modelList: [LocationModel]?)
    {
//        self.viewModel?.bookmarkedLocations = modelList
        self.locationTableView.reloadData()
        
    }
    
    func setTableViewEditMode(bool:Bool)
    {
        DispatchQueue.main.async {
            self.locationTableView.setEditing(bool, animated: bool)
        }
    }
    
    func removeLocationFromBookmark(model : LocationModel)
    {
        CoreDataManager.shared.removeBookmark(lat: model.latitude, lon: model.longitude)
    }
    
}

extension LocationsListView : UITableViewDataSource, UITableViewDelegate
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel?.bookmarkedLocations?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier.LocationCellIdentifier.rawValue, for: indexPath) as? WeatherLocationTableViewCell
        cell?.selectionStyle = .none
        if let bookmarkedList = self.viewModel?.bookmarkedLocations
        {
            let model = bookmarkedList[indexPath.row]
            cell?.locationLabel.text = model.locationName ?? ""
            
//            cell?.tempLabel.text = "Temperature: \(model.)"
            
        }
        
        return cell ?? UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete
        {
            //
            
            self.locationTableView.beginUpdates()
            removeLocationFromBookmark(model: (self.viewModel?.bookmarkedLocations?[indexPath.row])!)
            self.viewModel?.bookmarkedLocations?.remove(at: indexPath.row)
           self.locationTableView.deleteRows(at: [indexPath], with: .automatic)
            DispatchQueue.main.async {
                self.locationTableView.endUpdates()
                self.locationTableView.isEditing = false
                self.locationTableView.setEditing(false, animated: false)
//                self.locationTableView.reloadData()
                self.isEdit = false
            }
            
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.delegate?.locationSelected(location: (self.viewModel?.bookmarkedLocations?[indexPath.row])!)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
//    private func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
//        // Return false if you do not want the specified item to be editable.
//        return true
//    }
    
    
}
