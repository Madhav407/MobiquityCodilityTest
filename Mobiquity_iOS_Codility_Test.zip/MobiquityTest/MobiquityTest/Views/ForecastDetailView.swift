//
//  ForecastDetailView.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 14/06/21.
//

import UIKit

protocol ForecastDetailViewDelegate : class  {
    func itemClicked()
}
class ForecastDetailView: UIView {
    
    var viewModel: ForecastDetailViewModel?
    var locationTableView : UITableView
    var delegate : ForecastDetailViewDelegate?
    
    var isEdit = true
    init(frame: CGRect, viewModel : ForecastDetailViewModel?, delegate : ForecastDetailViewDelegate?) {
        self.locationTableView = UITableView(frame: frame, style: .grouped)
        self.delegate = delegate
        self.viewModel = viewModel
        super.init(frame: frame)
        configureUI()

    }
    
    required init?(coder: NSCoder) {
        self.locationTableView = UITableView(frame: .zero, style: .grouped)

        super.init(frame: .zero)
//        fatalError("init(coder:) has not been implemented")
    }
        
    
    func configureUI()
    {
        self.backgroundColor = .white
//        locationTableView = UITableView()
        addSubview(locationTableView)
                
                // TableView - Configuration + Style
        locationTableView.estimatedRowHeight = 60
        locationTableView.rowHeight = UITableView.automaticDimension
        
        let nib = UINib(nibName: "ForecastTableViewCell", bundle: Bundle.main)

        locationTableView.register(nib, forCellReuseIdentifier: CellIdentifier.ForecastTableViewCell.rawValue)
        locationTableView.delegate = self
        locationTableView.dataSource = self
        // TableView - Auto layout
        locationTableView.translatesAutoresizingMaskIntoConstraints = false
//        locationTableView.layer.borderWidth = 1
        let margins = self.safeAreaLayoutGuide
        locationTableView.leadingAnchor.constraint(equalTo: margins.leadingAnchor).isActive = true
        locationTableView.trailingAnchor.constraint(equalTo: margins.trailingAnchor).isActive = true
        locationTableView.topAnchor.constraint(equalTo: margins.topAnchor).isActive = true
        locationTableView.bottomAnchor.constraint(equalTo: margins.bottomAnchor).isActive = true
        locationTableView.bottomAnchor.constraint(equalTo: margins.bottomAnchor, constant: 50).isActive = true
        
    }
    
    func refreshLocationList(modelList: [LocationModel]?)
    {
        self.locationTableView.reloadData()
    }
    
}

extension ForecastDetailView : UITableViewDataSource, UITableViewDelegate
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel?.groupSortedArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sectionRowArray = viewModel?.groupSortedArray?[section] as? [List]
        {
            return sectionRowArray.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier.ForecastTableViewCell.rawValue, for: indexPath) as? ForecastTableViewCell
        cell?.selectionStyle = .none
        if let list = self.viewModel?.groupSortedArray?[indexPath.section] as? [List]
        {
        let model = list[indexPath.row]
            cell?.tempLabel.text = "\(model.main?.temp ?? 0.0)ºC"
            cell?.cloudLabel.text = "\(model.clouds?.all ?? 0)%" //can be used string interpolator
            cell?.windLabel.text = "\((model.wind?.speed ?? 0)) m/s" //can be used string interpolator
            cell?.rainLabel.text = "\(model.rain?.the3H ?? 0)mm" //can be used string interpolator
            cell?.humidityLabel.text = "\(model.main?.humidity ?? 0)%" //can be used string interpolator
        }
        return cell ?? UITableViewCell()
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if let sectionRowArray = viewModel?.groupSortedArray?[section] as? [List], sectionRowArray.count>0
        {
            let model = sectionRowArray[0]
            if let headerView = CustomViews.loadFromNib() as? CustomViews
            {
                headerView.sectionTitleLabel.text = model.dtTxt ?? ""
                return headerView
            }
        }
        return UIView()
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    
}
