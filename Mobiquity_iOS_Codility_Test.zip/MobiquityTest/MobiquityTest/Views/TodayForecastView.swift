//
//  TodayForecastView.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import UIKit

class TodayForecastView: UIView {
    
    var viewModel: TodayForecastViewModel?
    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()

    var weatherCollectionView : UICollectionView?
    
    var isEdit = true
    init(frame: CGRect, viewModel : TodayForecastViewModel?) {
        self.viewModel = viewModel
        weatherCollectionView = UICollectionView(frame: frame, collectionViewLayout: layout)
        super.init(frame: frame)
        configureUI()

    }
    
    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")

        weatherCollectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        super.init(frame: .zero)
    }
        
    func configureUI()
    {
        self.backgroundColor = .white
        layout.sectionInset = UIEdgeInsets(top: 20, left: 10, bottom: 10, right: 10)
        layout.itemSize = CGSize(width: SCREEN_WIDTH-2*6, height: 120)

         weatherCollectionView = UICollectionView(frame: frame, collectionViewLayout: layout)
        addSubview(weatherCollectionView!)
        weatherCollectionView?.backgroundColor = .white
        
        let nib = UINib(nibName: "TodayWeatherCollectionViewCell", bundle: Bundle.main)
        weatherCollectionView?.register(nib, forCellWithReuseIdentifier: "TodayWeatherCollectionViewCell")

//        locationTableView.register(nib, forCellReuseIdentifier: CellIdentifier.ForecastTableViewCell.rawValue)
        weatherCollectionView?.delegate = self
        weatherCollectionView?.dataSource = self
//        // TableView - Auto layout
//        locationTableView.translatesAutoresizingMaskIntoConstraints = false
//        locationTableView.layer.borderWidth = 1
        let margins = self.safeAreaLayoutGuide
        weatherCollectionView?.leadingAnchor.constraint(equalTo: margins.leadingAnchor).isActive = true
        weatherCollectionView?.trailingAnchor.constraint(equalTo: margins.trailingAnchor).isActive = true
        weatherCollectionView?.topAnchor.constraint(equalTo: margins.topAnchor).isActive = true
        weatherCollectionView?.bottomAnchor.constraint(equalTo: margins.bottomAnchor).isActive = true
        weatherCollectionView?.bottomAnchor.constraint(equalTo: margins.bottomAnchor, constant: 50).isActive = true
        
    }
    
   
}

extension TodayForecastView : UICollectionViewDataSource, UICollectionViewDelegate
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
        {
            return 1
        }

        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TodayWeatherCollectionViewCell", for: indexPath as IndexPath) as? TodayWeatherCollectionViewCell
            cell?.bgContentView.addShadow(offset: CGSize.init(width: 0, height: 3), color: UIColor.darkGray, radius: 1.0, opacity: 0.35)
            cell?.bgContentView.layer.cornerRadius = 8
            let model = self.viewModel?.weatherModel
            cell?.tempLabel.text = "\(model?.main?.temp ?? 0) ºC"
            cell?.humidityLabel.text = "\(model?.main?.humidity ?? 0) %"
            cell?.windLabel.text = "\(model?.wind?.speed ?? 0) m/s"
            cell?.rainLabel.text = "\(model?.clouds?.all ?? 0) %"

            return cell ?? UICollectionViewCell()
        }

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
        {
            return CGSize(width: SCREEN_WIDTH-2*10, height: 50)
        }

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets
        {
            return UIEdgeInsets(top: 5, left: 6, bottom: 5, right: 6)
        }
}
