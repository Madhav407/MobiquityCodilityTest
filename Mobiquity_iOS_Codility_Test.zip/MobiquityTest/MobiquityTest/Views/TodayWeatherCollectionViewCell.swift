//
//  TodayWeatherCollectionViewCell.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import UIKit

class TodayWeatherCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var bgContentView: UIView!
    
    @IBOutlet weak var humidityLabel: UILabel!
    
    @IBOutlet weak var windLabel: UILabel!
    @IBOutlet weak var rainLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
