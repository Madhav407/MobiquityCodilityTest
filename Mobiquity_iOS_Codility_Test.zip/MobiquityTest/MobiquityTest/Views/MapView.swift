//
//  MapView.swift
//  MobiquityTest
//
//  Created by Bhogapurau MadhavaRao on 13/06/21.
//

import UIKit

class MapView: UIView {
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
}
