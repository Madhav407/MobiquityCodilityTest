//
//  MockServiceHandler.swift
//  MobiquityTestTests
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import UIKit
@testable import MobiquityTest


class MockServiceHandler: NSObject {

    static let shared = MockServiceHandler()
    
    func getJSONDataForTodayForecast(type : ServiceType) -> Any?
    {
        var fileName = "TodayForecastWeather"
        if type == .foreCast
        {
            fileName = "ForecastFiveDay"
        }
        
        let bundle = Bundle(for: MobiquityTestTests.self)
        if let url = bundle.url(forResource: fileName, withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                if type == .today
                {
                    let model = try decoder.decode(LocationsModel.self, from: data)
                return model
                }
                else
                {
                    let model = try decoder.decode(ForecastDetailModel.self, from: data)
                    return model

                }
            } catch {
                print("error:\(error)")
            }
        }
        return nil
        
    }
   
}
