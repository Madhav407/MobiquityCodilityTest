//
//  HelpViewControllerTests.swift
//  MobiquityTestTests
//
//  Created by Bhogapurapu MadhavaRao on 15/06/21.
//

import XCTest
@testable import MobiquityTest

class HelpViewControllerTests: XCTestCase {

    override func setUpWithError() throws {
        
        let helpVC = HelpViewController()
        XCTAssertNotNil(helpVC)
        helpVC.viewDidLoad()
        helpVC.configureUI()
        let helpv = HellpWebview(coder: NSCoder())
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
