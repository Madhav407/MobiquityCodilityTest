//
//  MockDelegateTests.swift
//  MobiquityTestTests
//
//  Created by Bhogapurapu MadhavaRao on 15/06/21.
//

import XCTest
import CoreData

@testable import MobiquityTest

class MockDelegateTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        let context = CoreDataManager.shared.appDelegate?.persistentContainer.viewContext
        var locModel = NSEntityDescription.insertNewObject(forEntityName: "LocationModel", into: context!) as? LocationModel
        let delegate = MockDelegate()
        delegate.locationSelected(location: locModel!)
        delegate.refreshBookmarkedLocationsList()
        delegate.updateBookMarkWhileLocationChanged()
        delegate.updateNewBookMarkForSelectedLocationONMap(lat: Double(locModel!.latitude), lon: Double(locModel!.longitude))
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
