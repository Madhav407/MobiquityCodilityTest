//
//  ForecastWeatherViewControllerTests.swift
//  MobiquityTestTests
//
//  Created by Bhogapurapu MadhavaRao on 15/06/21.
//

import XCTest
@testable import MobiquityTest

class ForecastWeatherViewControllerTests: XCTestCase {
    var detailsModel : ForecastDetailModel?

    var forecastVC : ForecastWeatherViewController?
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        if let model = MockServiceHandler.shared.getJSONDataForTodayForecast(type: .foreCast) as? ForecastDetailModel
        {
            detailsModel = model
            XCTAssertNotNil(detailsModel)
        }
        Coordinator(getFiveDayForecastDetailsVC: ForecastDetailViewModel(forecastModel: detailsModel)) { (forecastVC) in
            
            XCTAssertNotNil(forecastVC)

            self.forecastVC = forecastVC
            forecastVC.viewDidLoad()
            forecastVC.configureUI()
            self.forecastVC?.viewModel = ForecastDetailViewModel(forecastModel: detailsModel)
            self.forecastVC?.detailsView?.refreshLocationList(modelList: nil)
            self.forecastVC?.detailsView?.viewModel = ForecastDetailViewModel(forecastModel: detailsModel)
            self.forecastVC?.itemClicked()
        }
        
        if let tableView = self.forecastVC?.detailsView?.locationTableView
        {
        self.forecastVC?.detailsView?.tableView(tableView, cellForRowAt: IndexPath(row: 0, section: 0))
            
            XCTAssertNotNil(self.forecastVC?.detailsView?.tableView(tableView, viewForHeaderInSection: 0))
            XCTAssertNotNil(self.forecastVC?.detailsView?.tableView(tableView, heightForHeaderInSection: 0))
            self.forecastVC?.detailsView?.viewModel?.groupSortedArray = nil
            XCTAssertNotNil(self.forecastVC?.detailsView?.tableView(tableView, viewForHeaderInSection: 0))

        }
        
        let tempVC = ForecastWeatherViewController(coder: NSCoder())
        XCTAssertNotNil(tempVC)
        
       
    
        XCTAssertNotNil(CustomViews.loadFromNib(tag: 101))
        XCTAssertNotNil(CustomViews.loadFromNib(tag: 104))
        let fview = ForecastDetailView(coder: NSCoder())
        XCTAssertNotNil(fview)

    }
    
    func testExtensions()
    {
        let floatValue : Float = 6.666
        let floatValue2  = 6.666
        
//        XCTAssertNotNil(floatValue2.formatted(4))

        XCTAssertNotNil(floatValue.roundedTo(decimals: 2))
        self.forecastVC?.detailsView?.addShadow(offset: CGSize(width: 0, height: 1), color: .gray, radius: 3, opacity: 0.2)
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
