//
//  TodayForecastVCTests.swift
//  MobiquityTestTests
//
//  Created by Bhogapurapu MadhavaRao on 15/06/21.
//

import XCTest
@testable import MobiquityTest

class TodayForecastVCTests: XCTestCase {

    var viewModel : TodayForecastViewModel?
    var todayVC : TodayForecastViewController?
    
    override func setUpWithError() throws {
        
        if let model = MockServiceHandler.shared.getJSONDataForTodayForecast(type: .today) as? LocationsModel
        {
            viewModel = TodayForecastViewModel(model: model)
        }
        
        Coordinator(getTodayForecastVC: viewModel) { (todayVC) in
            
            XCTAssertNotNil(todayVC)
            self.todayVC? = todayVC
            todayVC.viewDidLoad()
            self.todayVC?.prepareViewSetup()
            self.todayVC?.viewModel = viewModel
//            self.todayVC?.todayView?.weatherCollectionView?.reloadData()
            if let cView = todayVC.todayView?.weatherCollectionView
             {
                XCTAssertNil(self.todayVC?.todayView?.collectionView(cView, numberOfItemsInSection: 0))
                
                XCTAssertNil(self.todayVC?.todayView?.collectionView(cView, cellForItemAt: IndexPath(item: 0, section: 0)))
             }
            
            
        }
        
        let todayFVC = TodayForecastViewController(viewModel: viewModel)
        todayFVC.prepareViewSetup()
        
     
        let todayView = TodayForecastView(frame: .zero, viewModel: viewModel)
        
        XCTAssertNotNil(todayView.collectionView(todayView.weatherCollectionView!, cellForItemAt: IndexPath(item: 0, section: 0)))
        XCTAssertNotNil(todayView.collectionView(todayView.weatherCollectionView!, layout: todayView.layout, sizeForItemAt: IndexPath(item: 0, section: 0)))

        XCTAssertNotNil(todayView.collectionView(todayView.weatherCollectionView!, layout: todayView.layout, insetForSectionAt: 0))
        
        XCTAssertNotNil(TodayForecastViewController(coder: NSCoder()))
        let todayView2 = TodayForecastView(coder: NSCoder())
        XCTAssertNotNil(todayView2)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
