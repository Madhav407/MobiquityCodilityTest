//
//  MapViewControllerTests.swift
//  MobiquityTestTests
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import XCTest
import CoreLocation
import MapKit

@testable import MobiquityTest

class MapViewControllerTests: XCTestCase {

    var  viewModel: LocationsListViewModel?
    
    override func setUpWithError() throws {
        if let model = MockServiceHandler.shared.getJSONDataForTodayForecast(type: .today) as? LocationsModel
        {
            viewModel = LocationsListViewModel(model: model, delegate: MockDelegate())
        }
            
 
       let mapVC = MapViewController()
        mapVC.mapView = MKMapView(frame: .zero)
        
        var coordinate = CLLocationCoordinate2D(latitude:viewModel?.locationModel?.coord?.lat ?? 0.0, longitude: viewModel?.locationModel?.coord?.lon ?? 0.0)
        mapVC.viewDidLoad()
        mapVC.addCurrentLocation()
        mapVC.addToBookMarks()

        mapVC.handleTap(UITapGestureRecognizer(target: self, action: nil))
        
        
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
