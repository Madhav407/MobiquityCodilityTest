//
//  CoreDataManagerTests.swift
//  MobiquityTestTests
//
//  Created by Bhogapurapu MadhavaRao on 15/06/21.
//

import XCTest
import CoreData

@testable import MobiquityTest

class CoreDataManagerTests: XCTestCase {

    override func setUpWithError() throws {
        let context = CoreDataManager.shared.appDelegate?.persistentContainer.viewContext

        CoreDataManager.shared.insertLocation(latitude: 15.5566, longitude: 65.666, locName: "Test")
//        do
//        {
//        var locModel = NSEntityDescription.insertNewObject(forEntityName: "LocationModel", into: context!) as? LocationModel
//            CoreDataManager.shared.appDelegate?.saveContext()
//        }
//        catch
//        {
//            print(error)
//        }
//        locModel?.longitude = 6.66
        
        CoreDataManager.shared.appDelegate?.saveContext()
        CoreDataManager.shared.removeAll()
        DispatchQueue.main.asyncAfter(deadline: .now()+0.2) {
            XCTAssertNotNil(CoreDataManager.shared.fetchBookmarkedLocations())

        }
        
        
        
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
