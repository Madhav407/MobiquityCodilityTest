//
//  ViewControllerTests.swift
//  MobiquityTestTests
//
//  Created by Bhogapurau MadhavaRao on 15/06/21.
//

import XCTest
import CoreData

@testable import MobiquityTest

class ViewControllerTests: XCTestCase {

    var viewModel : LocationsListViewModel?
    var listVC : LocationsListViewController?
    var detailsModel : ForecastDetailModel?
    override func setUpWithError() throws {
        if let model = MockServiceHandler.shared.getJSONDataForTodayForecast(type: .today) as? LocationsModel
        {
            viewModel = LocationsListViewModel(model: model, delegate: MockDelegate())
        }
        
        if let model = MockServiceHandler.shared.getJSONDataForTodayForecast(type: .foreCast) as? ForecastDetailModel
        {
            detailsModel = model
        }
        
        
        listVC = LocationsListViewController(viewModel: viewModel)
    }

    
    func testVCLifeCycles()
    {
        XCTAssertNotNil(listVC)
        listVC?.viewDidLoad()
        listVC?.addLocationAction(nil)
        listVC?.deleteAction(nil)
        listVC?.addLocationAction(UIBarButtonItem())
        listVC?.doneButton(UIBarButtonItem())
        listVC?.updateDoneButton()
        listVC?.updateBookMarkWhileLocationChanged()
    }

    func testViewFucntions()
    {
        let context = CoreDataManager.shared.appDelegate?.persistentContainer.viewContext
        var locModel = NSEntityDescription.insertNewObject(forEntityName: "LocationModel", into: context!) as? LocationModel
        self.viewModel?.bookmarkedLocations = Array(arrayLiteral: locModel!)
        
        listVC?.configureUI()
        if let tableView = listVC?.locView?.locationTableView
        {
            XCTAssertNotNil(listVC?.locView?.tableView(tableView, cellForRowAt: IndexPath(row: 0, section: 0)))
            listVC?.locView?.tableView(tableView, didSelectRowAt: IndexPath(row: 0, section: 0))

//            listVC?.locView?.tableView(tableView, canEditRowAt: IndexPath(row: 0, section: 0))
            listVC?.locView?.tableView(tableView, commit: .delete, forRowAt: IndexPath(row: 0, section: 0))

        }
         locModel = NSEntityDescription.insertNewObject(forEntityName: "LocationModel", into: context!) as? LocationModel
        self.viewModel?.bookmarkedLocations = Array(arrayLiteral: locModel!)
        let params = ["lat" : String(describing: self.viewModel?.locationModel?.coord?.lat ), "lon":String(describing: self.viewModel?.locationModel?.coord?.lon )]

        listVC?.getTodayForecaseWeather(params: params)
        listVC?.getFiveDayForecaseWeather(params: params)
        listVC?.updateNewBookMarkForSelectedLocationONMap(lat: self.viewModel?.locationModel?.coord?.lat ?? 0.0, lon: self.viewModel?.locationModel?.coord?.lon ?? 0.0)
        
        listVC?.moveToForecastWeather(model: detailsModel ?? ForecastDetailModel(cod: nil, message: nil, cnt: nil, list: nil, city: nil) )
        
        listVC?.moveToTodayForecast(model: viewModel?.locationModel ?? LocationsModel(coord: nil, weather: nil, base: nil, main: nil, visibility: nil, wind: nil, clouds: nil, dt: nil, sys: nil, timezone: nil, id: nil, name: nil, cod: nil))
        locModel?.latitude = Float(self.viewModel?.locationModel?.coord?.lat ?? 0.0)
        locModel?.longitude =  Float(self.viewModel?.locationModel?.coord?.lon ?? 0.0)
        listVC?.locationSelected(location: locModel! )
        if let locList = self.viewModel?.bookmarkedLocations, locList.count>0
        {
            listVC?.locationSelected(location: locList[0] )
        }
    }
    
    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
