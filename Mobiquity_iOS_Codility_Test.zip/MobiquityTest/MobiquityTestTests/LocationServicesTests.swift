//
//  LocationServicesTests.swift
//  MobiquityTestTests
//
//  Created by Bhogapurapu MadhavaRao on 15/06/21.
//

import XCTest
import CoreLocation

@testable import MobiquityTest

class LocationServicesTests: XCTestCase {

    override func setUpWithError() throws {
        let locMgr = LocationServices.shared.startLocationServices()
        LocationServices.shared.locationManager(LocationServices.shared.locManager!, didUpdateLocations: [CLLocation(latitude: 17.2455, longitude: 79.12333)])
        LocationServices.shared.currentLatitude = 17.2455
        LocationServices.shared.currentLongitude = 79.12333
//        LocationServices.shared.currentLocation = CLLocation(latitude: 17.2455, longitude: 79.12333)
        XCTAssertNotNil(LocationServices.shared.currentLocation)
        
        XCTAssertNotNil(LocationServices.shared.currentLatitude)
        XCTAssertNotNil(LocationServices.shared.currentLongitude)
        LocationServices.shared.stopUpdatingLocation()

    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
